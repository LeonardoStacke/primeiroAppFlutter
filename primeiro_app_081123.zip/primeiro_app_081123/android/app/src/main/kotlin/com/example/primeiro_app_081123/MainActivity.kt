package com.example.primeiro_app_081123

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
